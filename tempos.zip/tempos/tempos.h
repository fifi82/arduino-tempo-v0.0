/*

tempos pour arduino

*/

#ifndef __tempos_H__
#define __tempos_H__


#include "Arduino.h"

class tempos
{
  public:
    //tempos();
    bool run = false;   // état de la tempo
    bool ok();
    float val();
    void set(float val);
    void start();
    void start(float val);
    void pause();
    void stop();

  private:
    unsigned long vt;   // calcul de la tempo qui se déroule
    float val_t = 1.0;  // par défaut la tempo est 1 seconde
    unsigned long t0;   // temps en cours
    unsigned long t_stop = val_t * 1000;   // temps d'arret    
};

#endif
